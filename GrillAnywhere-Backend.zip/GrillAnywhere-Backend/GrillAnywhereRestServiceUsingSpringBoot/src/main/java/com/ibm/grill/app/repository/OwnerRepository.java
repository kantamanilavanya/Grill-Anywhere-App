package com.ibm.grill.app.repository;

import org.springframework.data.repository.CrudRepository;

import com.ibm.grill.app.model.OwnerRegister;

public interface OwnerRepository extends CrudRepository<OwnerRegister,Integer> {

}
