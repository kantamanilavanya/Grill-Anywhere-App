package com.ibm.grill.app.validation;

public class RenterValidator {

}
