package com.ibm.grill.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootEmpMgmtServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootEmpMgmtServiceApplication.class, args);
	}

}
