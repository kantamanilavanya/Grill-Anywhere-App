package com.ibm.grill.app.repository;

import org.springframework.data.repository.CrudRepository;

import com.ibm.grill.app.model.RenterRegister;

public interface RenterRepository extends CrudRepository<RenterRegister,Integer> {

}
