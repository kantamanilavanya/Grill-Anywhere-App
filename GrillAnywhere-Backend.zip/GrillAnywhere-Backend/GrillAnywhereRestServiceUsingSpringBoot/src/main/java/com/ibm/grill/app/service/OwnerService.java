package com.ibm.grill.app.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ibm.grill.app.model.OwnerRegister;
import com.ibm.grill.app.repository.OwnerRepository;
@Service
public class OwnerService {

	@Autowired
	private static OwnerRepository owner;

	public static boolean add(OwnerRegister oregister) {

		owner.save(oregister);
		return true;
	}
	public List<OwnerRegister> get() {
        return (List<OwnerRegister>) owner.findAll();
    }
}
