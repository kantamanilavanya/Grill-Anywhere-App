package com.ibm.grill.app.controller;

public class RenterRegistrationController {

}
